/**
 * Line-oriented terminal frontend API and rendering helpers.
 *
 * Runtime sessions expose semantic steps and input bindings; this layer decides
 * how a text terminal displays them, reads input, and renders view commands.
 */

package rylween.frontend.terminal

import rylween.dsl.CharacterModel
import rylween.dsl.CharacterPlacementModel
import rylween.dsl.DungeonSystemModel
import rylween.dsl.GameModel
import rylween.dsl.GamePromptsModel
import rylween.dsl.GridPoint
import rylween.dsl.InputBindingModel
import rylween.dsl.IntAst
import rylween.dsl.InventorySaveSlotMax
import rylween.dsl.InventorySlotChoiceFilter
import rylween.dsl.LocationId
import rylween.dsl.MemberChoiceFilter
import rylween.dsl.NativeAllowlist
import rylween.dsl.NativeStringArg
import rylween.dsl.NpcJobId
import rylween.dsl.NpcRole
import rylween.dsl.PartyMemberState
import rylween.dsl.PartyState
import rylween.dsl.PcClass
import rylween.dsl.PronounCase
import rylween.dsl.StandardYesNoKeys
import rylween.dsl.StrAst
import rylween.dsl.TextBlock
import rylween.dsl.TextPart
import rylween.dsl.TownId
import rylween.dsl.TownModel
import rylween.dsl.ViewCommand
import rylween.dsl.WorldPosition
import rylween.dsl.YesNoKeysModel
import rylween.dsl.fallbackText
import rylween.dsl.inlineText
import rylween.dsl.inputKey
import rylween.dsl.matches
import rylween.dsl.pronoun
import rylween.engine.EngineTraceEvent
import rylween.runtime.InputCommand
import rylween.runtime.RuntimeSessionState
import rylween.runtime.wilderness.WildernessDungeonHandoff
import rylween.runtime.wilderness.WorldMapViewport

/** Minimal line-oriented terminal I/O and rendering port used by adapters. */
interface TerminalPort {
    fun write(lines: List<String>)

    fun writeBlocks(
        blocks: List<TextBlock>,
        renderer: TerminalTextRenderer,
        context: TerminalTextContext,
    ) {
        write(blocks.flatMap { block -> renderer.lines(block, context) })
    }

    fun readLine(): String?

    fun readTextLine(maxLength: Int? = null): String? = readLine()

    fun readReturn(): Boolean? = readLine()?.let { true }

    fun pause(ms: Int) {}

    /** Ends an auto-continued output frame before the adapter writes the next prompt. */
    fun finishOutputFrame() {}

    fun writeViewCommand(
        command: ViewCommand,
        renderer: TerminalTextRenderer,
        context: TerminalTextContext,
    ): Boolean = false

    fun writeEngineEvent(
        event: EngineTraceEvent,
        renderer: TerminalTextRenderer,
        context: TerminalTextContext,
    ): Boolean =
        when (event) {
            is EngineTraceEvent.View -> writeViewCommand(event.command, renderer, context)
            else -> false
        }
}

/** Writes a text prompt followed by an allowed-character key prompt. */
fun TerminalPort.writeKeyPrompt(
    renderer: TerminalTextRenderer,
    block: TextBlock,
    keys: List<Char>,
    context: TerminalTextContext = TerminalTextContext(),
) {
    write(renderer.keyPromptLines(block, keys, context))
}

/** Writes a text prompt followed by labeled input bindings. */
fun TerminalPort.writeBindingPrompt(
    renderer: TerminalTextRenderer,
    block: TextBlock,
    bindings: List<InputBindingModel>,
    context: TerminalTextContext = TerminalTextContext(),
) {
    write(renderer.bindingPromptLines(block, bindings, context))
}

/** Runtime values available while rendering dynamic [TextBlock] parts. */
data class TerminalTextContext(
    val shopPrice: Int? = null,
    val shopCarryCap: Int? = null,
    val offeredItemName: String? = null,
    val offeredItemPrice: Int? = null,
    val selectedItemName: String? = null,
    val runtime: RuntimeSessionState? = null,
    val huntMemberNumber: Int? = null,
    val huntFoodGained: Int? = null,
)

/** Details of a rejected terminal input for resumable/blocking adapters. */
data class TerminalInputRejection(
    val input: String,
    val expected: List<String>,
)

/** Completion or waiting status returned by a terminal adapter. */
sealed interface TerminalRunStatus {
    object Finished : TerminalRunStatus

    data class Waiting(
        val rejection: TerminalInputRejection? = null,
    ) : TerminalRunStatus

    object StepLimitReached : TerminalRunStatus
}

/** Session plus status returned when an adapter finishes or blocks for input. */
data class TerminalAdapterResult<S>(
    val session: S,
    val status: TerminalRunStatus,
)

/** Returns [updated] after a child step, or reports the blocking terminal status to [stop]. */
inline fun <S> continueOrBlock(
    updated: S,
    status: TerminalRunStatus,
    stop: (TerminalAdapterResult<S>) -> Nothing,
): S =
    when (status) {
        TerminalRunStatus.Finished -> updated
        TerminalRunStatus.StepLimitReached -> stop(TerminalAdapterResult(updated, TerminalRunStatus.StepLimitReached))
        is TerminalRunStatus.Waiting -> stop(TerminalAdapterResult(updated, status))
    }

/** Runs a nested terminal adapter and projects its blocking status back onto the parent session. */
inline fun <P, C> runChildOrBlock(
    parent: P,
    child: C,
    run: (C) -> TerminalAdapterResult<C>,
    replace: (P, C) -> P,
    stop: (TerminalAdapterResult<P>) -> Nothing,
): P {
    val result = run(child)
    val updated = replace(parent, result.session)
    return continueOrBlock(updated, result.status, stop)
}

/** Formats one input binding as the conventional `(K)label` terminal menu line. */
fun bindingMenuLine(
    binding: InputBindingModel,
    label: String,
): String {
    val marker = binding.primaryChar.uppercaseChar()
    val cleanLabel = label.trim()
    val suffix =
        if (cleanLabel.firstOrNull()?.uppercaseChar() == marker) {
            cleanLabel.drop(1)
        } else {
            " $cleanLabel"
        }
    return "($marker)$suffix"
}

/** Creates a terminal renderer with game text references and optional overrides. */
fun GameModel.terminalTextRenderer(references: Map<String, List<String>> = emptyMap()): TerminalTextRenderer =
    TerminalTextRenderer(
        references = references,
        towns = towns,
        characters = characters,
        dungeons = dungeons,
        prompts = prompts,
    )

/** Renders authored [TextBlock] and view-command text into terminal lines. */
class TerminalTextRenderer(
    private val references: Map<String, List<String>> = emptyMap(),
    towns: List<TownModel> = emptyList(),
    characters: List<CharacterModel> = emptyList(),
    private val dungeons: DungeonSystemModel = DungeonSystemModel(),
    private val prompts: GamePromptsModel = GamePromptsModel(),
) {
    private val worldText = TerminalWorldTextResolver(towns, characters)

    fun lines(
        block: TextBlock,
        context: TerminalTextContext = TerminalTextContext(),
    ): List<String> =
        when (block) {
            is TextBlock.Inline -> block.lines
            is TextBlock.Ref -> references[block.id.id] ?: listOf("[${block.id.id}]")
            is TextBlock.Structured ->
                block.lines.map { line ->
                    line.parts.joinToString(separator = "") { part -> render(part, context) }
                }
        }

    fun worldMapViewportLines(viewport: WorldMapViewport): List<String> =
        viewport.rows.map { row ->
            row.joinToString(separator = "") { cell ->
                if (cell.isCenter) "@" else (cell.tile ?: ' ').toString()
            }
        }

    fun keyPromptLines(
        block: TextBlock,
        keys: List<Char>,
        context: TerminalTextContext = TerminalTextContext(),
    ): List<String> = choicePromptLines(block, keys.map { it.toString() }, markerKeys = keys, context)

    fun bindingPromptLines(
        block: TextBlock,
        bindings: List<InputBindingModel>,
        context: TerminalTextContext = TerminalTextContext(),
    ): List<String> =
        choicePromptLines(
            block,
            labels = bindings.map { it.label },
            markerKeys = bindings.map { it.primaryChar },
            context = context,
        )

    private fun choicePromptLines(
        block: TextBlock,
        labels: List<String>,
        markerKeys: List<Char>,
        context: TerminalTextContext = TerminalTextContext(),
    ): List<String> {
        val rendered = lines(block, context)
        val options =
            if (labels.isEmpty() || rendered.containsKeyMarkers(markerKeys)) {
                emptyList()
            } else {
                listOf("Options: ${labels.joinToString("/")}")
            }
        return rendered + options
    }

    fun dungeonHandoffPrompt(handoff: WildernessDungeonHandoff): TextBlock =
        prompts.wilderness.renderDungeonHandoff(dungeons.displayName(handoff.dungeon), handoff.levels)

    private fun render(
        part: TextPart,
        context: TerminalTextContext,
    ): String =
        when (part) {
            is TextPart.Literal -> part.text
            is TextPart.IntValue -> render(part.value)
            is TextPart.StringValue -> render(part.value, context)
            is TextPart.RoleName -> worldText.roleName(part.role) ?: part.fallbackText()
            is TextPart.RoleLocation ->
                worldText.roleLocation(part.role, context.runtime)
                    ?: part.fallbackText()
            is TextPart.TownName -> worldText.townName(part.town)
            is TextPart.FuzzyTownLocation ->
                worldText.townLocation(part.town, part.radius)
                    ?: part.fallbackText()
            is TextPart.LocationCoordinate ->
                locationCoordinate(part.location, context.runtime)
                    ?: part.fallbackText()
            TextPart.OfferedItemName -> context.offeredItemName ?: part.fallbackText()
            TextPart.OfferedItemPrice -> context.offeredItemPrice?.toString() ?: part.fallbackText()
            TextPart.SelectedItemName -> context.selectedItemName ?: part.fallbackText()
            TextPart.ShopPrice -> context.shopPrice?.toString() ?: part.fallbackText()
            TextPart.ShopCarryCap -> context.shopCarryCap?.toString() ?: part.fallbackText()
            TextPart.HuntMemberName -> huntMember(context)?.name ?: part.fallbackText()
            TextPart.HuntMemberSubjectPronoun -> huntMemberSubjectPronoun(context) ?: part.fallbackText()
            TextPart.HuntFoodGained -> context.huntFoodGained?.toString() ?: part.fallbackText()
            TextPart.PartyMemberMax ->
                context.runtime
                    ?.realm
                    ?.partyMemberMax
                    ?.toString() ?: part.fallbackText()
            TextPart.WildernessDungeonName,
            TextPart.WildernessDungeonLevels,
            TextPart.DungeonDepth,
            TextPart.ConversationNpcName,
            TextPart.CurrentTownName,
            TextPart.TownTaxPercent,
            TextPart.TownTaxAmount,
            TextPart.CreationMemberNumber,
            TextPart.CreationMemberName,
            TextPart.CreationWeaponSkill,
            TextPart.CreationHealth,
            TextPart.CreationWisdom,
            TextPart.CreationCharisma,
            TextPart.BattleFoeDisplayName,
            TextPart.BattleAttackerName,
            TextPart.BattleTargetName,
            TextPart.BattleDamage,
            TextPart.BattleExperience,
            TextPart.BattleGold,
            TextPart.BattleLootName,
            TextPart.BattleLevelMemberName,
            TextPart.BattleLevelsGained,
            -> part.fallbackText()
        }

    fun pausePrompt(verbIndex: Int? = null): TextBlock {
        val verb =
            verbIndex
                ?.let { prompts.pauseVerbs.getOrNull(it) }
                ?: prompts.pauseVerbs.firstOrNull()
                ?: "Press"
        return inlineText("($verb ${prompts.returnKeyName})")
    }

    fun pauseVerbIndexRange(): IntRange? = prompts.pauseVerbs.takeIf { it.isNotEmpty() }?.indices

    private fun render(
        ast: StrAst,
        context: TerminalTextContext,
    ): String =
        when (ast) {
            is StrAst.NativeString ->
                when (ast.path) {
                    NativeAllowlist.partyMemberName.path -> {
                        val index = ast.args.singleOrNull()?.literalInt()
                        index?.let {
                            context.runtime
                                ?.activeParty
                                ?.members
                                ?.getOrNull(it - 1)
                                ?.name
                        } ?: "{party.name}"
                    }
                    NativeAllowlist.partyPronounSubject.path ->
                        renderPronoun(ast, context, PronounCase.Subject)
                    NativeAllowlist.partyPronounObject.path ->
                        renderPronoun(ast, context, PronounCase.Object)
                    NativeAllowlist.partyPronounPossessive.path ->
                        renderPronoun(ast, context, PronounCase.Possessive)
                    NativeAllowlist.townNpcName.path -> {
                        val job =
                            ast.args
                                .singleOrNull()
                                ?.literalString()
                                ?.let(::NpcJobId)
                        job?.let { worldText.townNpcName(it, context.runtime) } ?: "{town.npc.name}"
                    }
                    NativeAllowlist.npcRoleName.path -> {
                        val role =
                            ast.args
                                .singleOrNull()
                                ?.literalString()
                                ?.let(::NpcRole)
                        role?.let(worldText::roleName) ?: "{npc.role.name}"
                    }
                    NativeAllowlist.npcRoleLocation.path -> {
                        val role =
                            ast.args
                                .singleOrNull()
                                ?.literalString()
                                ?.let(::NpcRole)
                        role?.let { worldText.roleLocation(it, context.runtime) } ?: "{npc.role.location}"
                    }
                    else -> "{${ast.path}}"
                }
        }

    private fun renderPronoun(
        ast: StrAst.NativeString,
        context: TerminalTextContext,
        case: PronounCase,
    ): String {
        val index = ast.args.singleOrNull()?.literalInt()
        val gender =
            index?.let {
                context.runtime
                    ?.activeParty
                    ?.members
                    ?.getOrNull(it - 1)
                    ?.gender
            } ?: return "{pronoun}"
        return gender.pronoun(case)
    }

    private fun huntMember(context: TerminalTextContext): PartyMemberState? {
        val memberNumber = context.huntMemberNumber ?: return null
        return context.runtime
            ?.activeParty
            ?.members
            ?.getOrNull(memberNumber - 1)
    }

    private fun huntMemberSubjectPronoun(context: TerminalTextContext): String? = huntMember(context)?.gender?.pronoun(PronounCase.Subject)

    private fun NativeStringArg.literalInt(): Int? =
        when (this) {
            is NativeStringArg.IntValue -> (value as? IntAst.Lit)?.value
            is NativeStringArg.Literal -> value.toIntOrNull()
        }

    private fun NativeStringArg.literalString(): String? =
        when (this) {
            is NativeStringArg.IntValue -> (value as? IntAst.Lit)?.value?.toString()
            is NativeStringArg.Literal -> value
        }

    private fun locationCoordinate(
        location: LocationId,
        runtime: RuntimeSessionState?,
    ): String? =
        runtime
            ?.locations
            ?.firstOrNull { it.location == location }
            ?.point
            ?.let { TerminalWorldTextResolver.point(it) }

    private fun render(ast: IntAst): String =
        when (ast) {
            is IntAst.Lit -> ast.value.toString()
            else -> "{int}"
        }
}

/** Resolves world and character references while rendering dynamic terminal text. */
class TerminalWorldTextResolver(
    private val towns: List<TownModel> = emptyList(),
    private val characters: List<CharacterModel> = emptyList(),
) {
    fun townNpcName(
        job: NpcJobId,
        runtime: RuntimeSessionState?,
    ): String? {
        val town = runtime?.realm?.currentTown ?: return null
        return characters
            .firstOrNull { character ->
                character.job == job &&
                    position(character, runtime).let { position ->
                        position is WorldPosition.Town && position.town == town
                    }
            }?.name
    }

    fun roleName(role: NpcRole): String? = characterFor(role)?.name

    fun roleLocation(
        role: NpcRole,
        runtime: RuntimeSessionState?,
    ): String? {
        val character = characterFor(role) ?: return null
        return position(character, runtime)?.let(::position)
    }

    fun townName(town: TownId): String = towns.firstOrNull { it.id == town }?.name ?: town.slug

    fun townLocation(
        town: TownId,
        radius: Int,
    ): String? {
        val model = towns.firstOrNull { it.id == town } ?: return null
        return point(fuzzyPoint(model.position, town.slug, radius))
    }

    private fun characterFor(role: NpcRole): CharacterModel? = characters.firstOrNull { role in it.roles }

    private fun position(
        character: CharacterModel,
        runtime: RuntimeSessionState?,
    ): WorldPosition? =
        runtime
            ?.npcs
            ?.firstOrNull { it.npc == character.id }
            ?.position
            ?: (character.placement as? CharacterPlacementModel.Fixed)?.position

    private fun position(position: WorldPosition): String =
        when (position) {
            is WorldPosition.Town -> "in ${townName(position.town)}"
            is WorldPosition.Wilderness -> "at ${point(position.point)}"
        }

    private fun fuzzyPoint(
        point: GridPoint,
        slug: String,
        radius: Int,
    ): GridPoint =
        if (radius <= 0) {
            point
        } else {
            GridPoint(
                x = point.x + stableOffset("$slug:x", radius),
                y = point.y + stableOffset("$slug:y", radius),
            )
        }

    private fun stableOffset(
        key: String,
        radius: Int,
    ): Int {
        val span = radius * 2 + 1
        val hash = key.fold(0) { acc, char -> acc * 31 + char.code }
        return Math.floorMod(hash, span) - radius
    }

    companion object {
        fun point(point: GridPoint): String = "${point.x}x${point.y}"
    }
}

/** Writes engine trace events using terminal rendering rules. */
fun TerminalPort.writeScriptEvents(
    events: List<EngineTraceEvent>,
    renderer: TerminalTextRenderer,
    runtime: RuntimeSessionState,
    renderDungeonHandoff: Boolean = true,
    renderTownService: Boolean = false,
) {
    val context = TerminalTextContext(runtime = runtime)
    events.forEach { event ->
        if (writeEngineEvent(event, renderer, context)) {
            return@forEach
        }
        if (writePauseEvent(event, renderer, context)) {
            return@forEach
        }
        when (event) {
            is EngineTraceEvent.View -> Unit
            is EngineTraceEvent.Screen -> write(renderer.lines(event.text, context))
            is EngineTraceEvent.Emit -> write(listOf("[${event.id.id}]"))
            is EngineTraceEvent.EmitIndexed -> write(listOf("[${event.pattern.pattern}: ${event.value}]"))
            is EngineTraceEvent.Menu -> writeKeyPrompt(renderer, event.prompt, event.keys, context)
            is EngineTraceEvent.AskKey -> writeBindingPrompt(renderer, event.prompt, event.bindings, context)
            is EngineTraceEvent.AskText -> write(renderer.lines(event.prompt, context))
            is EngineTraceEvent.AskMember -> write(renderer.lines(event.prompt, context))
            is EngineTraceEvent.AskInventorySlot -> write(renderer.lines(event.prompt, context))
            is EngineTraceEvent.NativeEffect -> write(listOf("Native: ${event.request.path}"))
            is EngineTraceEvent.NativeInt -> write(listOf("Native int: ${event.request.path} = ${event.result}"))
            is EngineTraceEvent.NativeString -> write(listOf("Native string: ${event.request.path} = ${event.result}"))
            is EngineTraceEvent.Rumour -> write(listOf("Rumour: ${event.table.slug}"))
            is EngineTraceEvent.RunScene -> write(listOf("Scene: ${event.scene.slug}"))
            is EngineTraceEvent.DungeonHandoff ->
                if (renderDungeonHandoff) {
                    write(renderer.lines(renderer.dungeonHandoffPrompt(event.handoff), context))
                }
            is EngineTraceEvent.TeleportParty,
            is EngineTraceEvent.DiscoverCave,
            -> Unit
            is EngineTraceEvent.Stop,
            is EngineTraceEvent.Break,
            -> Unit
            is EngineTraceEvent.TownService ->
                if (renderTownService) {
                    write(listOf("Service: ${event.service.building.slug}"))
                }
            is EngineTraceEvent.WaitInput,
            is EngineTraceEvent.Pause,
            is EngineTraceEvent.SetFlag,
            is EngineTraceEvent.AppendJournal,
            is EngineTraceEvent.GrantReward,
            is EngineTraceEvent.AchieveMilestone,
            is EngineTraceEvent.Speak,
            is EngineTraceEvent.Encounter,
            is EngineTraceEvent.RandomItemOffer,
            is EngineTraceEvent.ShopService,
            is EngineTraceEvent.ShopSellQuote,
            is EngineTraceEvent.ShopTransaction,
            is EngineTraceEvent.EquipmentAction,
            is EngineTraceEvent.ConsumeInventoryPool,
            EngineTraceEvent.ConsumeTorch,
            -> Unit
        }
    }
}

/** Writes or performs a pause event according to terminal policy. */
fun TerminalPort.writePauseEvent(
    event: EngineTraceEvent,
    renderer: TerminalTextRenderer,
    context: TerminalTextContext,
): Boolean =
    when (event) {
        is EngineTraceEvent.WaitInput ->
            true.also {
                write(renderer.lines(event.prompt ?: renderer.pausePrompt(), context))
            }
        is EngineTraceEvent.Pause ->
            true.also {
                pause(event.ms)
            }
        else -> false
    }

/** Parsed terminal input value or waiting/rejection state. */
sealed interface TerminalInput<out T> {
    data class Value<T>(
        val value: T,
    ) : TerminalInput<T>

    data class Rejected(
        val rejection: TerminalInputRejection,
    ) : TerminalInput<Nothing>

    object Unavailable : TerminalInput<Nothing>
}

/** One parsed choice option bound to a terminal key. */
data class TerminalChoice<out T>(
    val value: T,
    val binding: InputBindingModel,
)

/** Converts semantic input commands into terminal choice options. */
fun <T> List<InputCommand<T>>.terminalChoices(): List<TerminalChoice<T>> = map { command -> TerminalChoice(command.input, command.binding) }

/** Numeric prompt value for input bindings that are displayed as menu digits. */
fun InputBindingModel.promptValue(): Int =
    primary.singleOrNull()?.let { char ->
        char.digitToIntOrNull() ?: char.uppercaseChar().code
    } ?: primary.uppercase().hashCode()

fun <T, R> TerminalInput<T>.map(transform: (T) -> R): TerminalInput<R> =
    when (this) {
        is TerminalInput.Value -> TerminalInput.Value(transform(value))
        is TerminalInput.Rejected -> this
        TerminalInput.Unavailable -> TerminalInput.Unavailable
    }

/** Applies a parsed input value to a session, or converts missing/rejected input into a wait result. */
inline fun <S, T> TerminalInput<T>.sessionOrWait(
    current: S,
    stop: (TerminalAdapterResult<S>) -> Nothing,
    update: (T) -> S,
): S =
    when (this) {
        is TerminalInput.Value -> update(value)
        is TerminalInput.Rejected -> stop(waiting(current, rejection))
        TerminalInput.Unavailable -> stop(waiting(current))
    }

/** Reads one key and validates it against [allowed]. */
fun TerminalPort.readKey(allowed: List<Char>): TerminalInput<Char> {
    val choices = allowed.map { key -> TerminalChoice(key, inputKey(key, label = key.toString())) }
    return readChoice(choices)
}

/** Choice list for a yes/no prompt. */
fun yesNoChoices(keys: YesNoKeysModel = StandardYesNoKeys): List<TerminalChoice<Boolean>> =
    listOf(
        TerminalChoice(true, keys.yes),
        TerminalChoice(false, keys.no),
    )

/** Allowed key list for a yes/no prompt. */
fun yesNoKeys(keys: YesNoKeysModel = StandardYesNoKeys): List<Char> = yesNoChoices(keys).map { it.binding.primaryChar }

/** Reads and parses a yes/no prompt. */
fun TerminalPort.readYesNo(keys: YesNoKeysModel = StandardYesNoKeys): TerminalInput<Boolean> = readChoice(yesNoChoices(keys))

/** Reads and parses one choice from [choices]. */
fun <T> TerminalPort.readChoice(choices: List<TerminalChoice<T>>): TerminalInput<T> {
    val raw = readLine() ?: return TerminalInput.Unavailable
    val choice = choices.firstOrNull { it.binding.matches(raw) }
    return if (choice != null) {
        TerminalInput.Value(choice.value)
    } else {
        TerminalInput.Rejected(TerminalInputRejection(raw, choices.map { it.binding.label }.distinct()))
    }
}

/** Reads one integer from the terminal. */
fun TerminalPort.readInt(): TerminalInput<Int> {
    val raw = readLine() ?: return TerminalInput.Unavailable
    return raw
        .trim()
        .toIntOrNull()
        ?.let { TerminalInput.Value(it) }
        ?: TerminalInput.Rejected(TerminalInputRejection(raw, listOf("integer")))
}

/** Reads one member number constrained to [allowed]. */
fun TerminalPort.readMemberNumber(allowed: List<Int>): TerminalInput<Int> {
    val raw = readLine() ?: return TerminalInput.Unavailable
    val memberNumber = raw.trim().toIntOrNull()
    return if (memberNumber != null && memberNumber in allowed) {
        TerminalInput.Value(memberNumber)
    } else {
        TerminalInput.Rejected(TerminalInputRejection(raw, allowed.map { it.toString() }))
    }
}

/** Builds a finished adapter result for [session]. */
fun <S> finished(session: S): TerminalAdapterResult<S> = TerminalAdapterResult(session, TerminalRunStatus.Finished)

/** Builds a waiting adapter result for [session]. */
fun <S> waiting(
    session: S,
    rejection: TerminalInputRejection? = null,
): TerminalAdapterResult<S> = TerminalAdapterResult(session, TerminalRunStatus.Waiting(rejection))

/** Terminal keys corresponding to inventory slots accepted by [filter]. */
fun PartyState.inventoryKeys(filter: InventorySlotChoiceFilter): List<Char> =
    inventorySlotChoices(filter, 1..InventorySaveSlotMax, 'A').map { it.first }

/** Terminal inventory-slot choices accepted by [filter]. */
fun PartyState.inventorySlotChoices(
    filter: InventorySlotChoiceFilter,
    slots: IntRange,
    firstKey: Char,
): List<Pair<Char, Int>> {
    val itemsBySlot = inventory.associate { it.slot to it.item }
    return slots
        .filter { slot ->
            slot in 1..InventorySaveSlotMax &&
                when (filter) {
                    InventorySlotChoiceFilter.Any -> true
                    InventorySlotChoiceFilter.NonEmpty -> itemsBySlot[slot] != null
                    InventorySlotChoiceFilter.Empty -> itemsBySlot[slot] == null
                }
        }.map { slot -> firstKey + (slot - slots.first) to slot }
}

/** Party member numbers accepted by [filter]. */
fun PartyState.memberChoices(filter: MemberChoiceFilter): List<Int> =
    members
        .mapIndexedNotNull { index, member ->
            (index + 1).takeIf { member.matches(filter) }
        }

/** Returns true when this party member satisfies [filter]. */
fun PartyMemberState.matches(filter: MemberChoiceFilter): Boolean =
    when (filter) {
        MemberChoiceFilter.Any -> true
        MemberChoiceFilter.AliveOnly -> !dead
        MemberChoiceFilter.DeadOnly -> dead
        MemberChoiceFilter.SpellcasterOnly -> !dead && pcClass in setOf(PcClass.Mage, PcClass.Priest)
    }

private fun List<String>.containsKeyMarkers(keys: List<Char>): Boolean {
    val promptLines = filter { it.isNotBlank() }
    return promptLines.isNotEmpty() &&
        keys.all { key ->
            val marker = "(${key.uppercaseChar()})"
            promptLines.any { line -> line.contains(marker, ignoreCase = true) }
        }
}
