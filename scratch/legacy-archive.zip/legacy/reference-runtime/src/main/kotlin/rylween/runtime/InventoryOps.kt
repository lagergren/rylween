/**
 * Pure [rylween.dsl.PartyState] operations for inventory, equipment, resources, and camp gear.
 *
 * Runtime sessions call these helpers when they need deterministic state
 * mutation without frontend policy, RNG, or authored-script execution.
 */

package rylween.runtime

import rylween.dsl.DslDefaultItems
import rylween.dsl.EquipmentCommand
import rylween.dsl.EquipmentPromptsModel
import rylween.dsl.EquipmentState
import rylween.dsl.FlagState
import rylween.dsl.GameMilestoneId
import rylween.dsl.ImageId
import rylween.dsl.InventorySaveSlotMax
import rylween.dsl.InventorySlotChoiceFilter
import rylween.dsl.InventorySlotState
import rylween.dsl.ItemId
import rylween.dsl.ItemKind
import rylween.dsl.ItemPoolId
import rylween.dsl.ItemRecordModel
import rylween.dsl.JournalEntryState
import rylween.dsl.MemberChoiceFilter
import rylween.dsl.PartyMemberState
import rylween.dsl.PartyState
import rylween.dsl.PcClass
import rylween.dsl.RealmContentModel
import rylween.dsl.Resource
import rylween.dsl.RewardOverflowPolicy
import rylween.dsl.TemperatureBand
import rylween.dsl.TextBlock
import rylween.dsl.image
import rylween.dsl.item
import rylween.dsl.lines
import rylween.dsl.matches
import rylween.dsl.milestone
import rylween.dsl.runtimeFlagState
import rylween.runtime.party.InventoryItemChoice

/** Result of trying to place an item into party inventory. */
sealed interface InventoryPlacementResult {
    data class Placed(
        val party: PartyState,
        val slot: Int,
    ) : InventoryPlacementResult

    data class NeedsDropSlot(
        val party: PartyState,
    ) : InventoryPlacementResult

    data class Full(
        val party: PartyState,
    ) : InventoryPlacementResult

    data class InvalidDropSlot(
        val party: PartyState,
        val slot: Int,
    ) : InventoryPlacementResult
}

/** Result of trying to equip or unequip one party member. */
sealed interface EquipmentActionResult {
    data class Equipped(
        val party: PartyState,
        val memberNumber: Int,
        val inventorySlot: Int,
    ) : EquipmentActionResult

    data class Unequipped(
        val party: PartyState,
        val memberNumber: Int,
        val inventorySlot: Int,
    ) : EquipmentActionResult

    data class InvalidMember(
        val party: PartyState,
        val memberNumber: Int,
    ) : EquipmentActionResult

    data class DeadMember(
        val party: PartyState,
        val memberNumber: Int,
    ) : EquipmentActionResult

    data class InvalidInventorySlot(
        val party: PartyState,
        val slot: Int,
    ) : EquipmentActionResult

    data class WrongItemKind(
        val party: PartyState,
        val slot: Int,
        val item: ItemId?,
    ) : EquipmentActionResult

    data class WrongClass(
        val party: PartyState,
        val memberNumber: Int,
        val slot: Int,
        val item: ItemId,
        val pcClass: PcClass,
    ) : EquipmentActionResult

    data class NothingEquipped(
        val party: PartyState,
        val memberNumber: Int,
        val kind: EquipmentKind,
    ) : EquipmentActionResult

    data class InventoryFull(
        val party: PartyState,
    ) : EquipmentActionResult
}

/** Result of consuming one torch for dungeon movement. */
sealed interface TorchActionResult {
    data class Consumed(
        val party: PartyState,
    ) : TorchActionResult

    data class NoTorches(
        val party: PartyState,
    ) : TorchActionResult
}

/** Result of attempting a dungeon descent step. */
sealed interface DungeonDescentResult {
    data class Descended(
        val party: PartyState,
    ) : DungeonDescentResult

    data class NoTorches(
        val party: PartyState,
    ) : DungeonDescentResult

    data class AtMaxDepth(
        val party: PartyState,
    ) : DungeonDescentResult
}

/** Aggregate protection and image contributed by carried camp gear. */
data class CampGearEffect(
    val image: ImageId,
    val protectedBands: Set<TemperatureBand>,
) {
    /** Returns true when carried camp gear protects against [band]. */
    fun protects(band: TemperatureBand): Boolean = band in protectedBands
}

/** Party state carried by every [EquipmentActionResult]. */
val EquipmentActionResult.party: PartyState
    get() =
        when (this) {
            is EquipmentActionResult.Equipped -> party
            is EquipmentActionResult.Unequipped -> party
            is EquipmentActionResult.InvalidMember -> party
            is EquipmentActionResult.DeadMember -> party
            is EquipmentActionResult.InvalidInventorySlot -> party
            is EquipmentActionResult.WrongItemKind -> party
            is EquipmentActionResult.WrongClass -> party
            is EquipmentActionResult.NothingEquipped -> party
            is EquipmentActionResult.InventoryFull -> party
        }

/** Maps equipment-action outcomes to a parent session status token. */
fun <T> EquipmentActionResult.toParentStatus(
    used: T,
    unavailable: T,
): T =
    when (this) {
        is EquipmentActionResult.Equipped,
        is EquipmentActionResult.Unequipped,
        -> used
        else -> unavailable
    }

/** Places [item] in the first free inventory slot or applies the configured overflow policy. */
fun PartyState.placeInventoryItem(
    item: ItemId,
    overflow: RewardOverflowPolicy = RewardOverflowPolicy.PromptDropThenPlace,
    dropSlot: Int? = null,
    itemRecords: List<ItemRecordModel> = emptyList(),
    realmContent: RealmContentModel = RealmContentModel(),
): InventoryPlacementResult {
    fun placed(slot: Int): InventoryPlacementResult.Placed =
        InventoryPlacementResult.Placed(
            withInventoryItem(slot, item).clampResourcesToCapacity(itemRecords, realmContent),
            slot,
        )

    firstFreeInventorySlot()?.let { return placed(it) }

    if (overflow == RewardOverflowPolicy.SkipIfInventoryFull) {
        return InventoryPlacementResult.Full(this)
    }

    val slot = dropSlot ?: return InventoryPlacementResult.NeedsDropSlot(this)
    if (slot !in 1..InventorySaveSlotMax || inventoryItem(slot) == null) {
        return InventoryPlacementResult.InvalidDropSlot(this, slot)
    }
    return placed(slot)
}

/** Equips an inventory item onto one member after validating slot, class, and kind. */
fun PartyState.equipFromInventory(
    memberNumber: Int,
    slot: Int,
    kind: EquipmentKind,
    itemRecords: List<ItemRecordModel> = emptyList(),
): EquipmentActionResult {
    val memberIndex = memberNumber - 1
    val member =
        members.getOrNull(memberIndex)
            ?: return EquipmentActionResult.InvalidMember(this, memberNumber)
    if (member.dead) return EquipmentActionResult.DeadMember(this, memberNumber)
    if (slot !in 1..InventorySaveSlotMax) return EquipmentActionResult.InvalidInventorySlot(this, slot)

    val item =
        inventoryItem(slot)
            ?: return EquipmentActionResult.WrongItemKind(this, slot, null)
    val record =
        itemRecords.associateBy { it.id }[item]
            ?: return EquipmentActionResult.WrongItemKind(this, slot, item)
    if (!record.matches(kind)) {
        return EquipmentActionResult.WrongItemKind(this, slot, item)
    }
    if (!record.canEquip(member.pcClass)) {
        return EquipmentActionResult.WrongClass(this, memberNumber, slot, item, member.pcClass)
    }

    val oldEquipped = member.equipment.item(kind)
    val updatedMember = member.withEquipmentItem(kind, item)
    val updatedInventoryItem = oldEquipped.takeUnless { it == DslDefaultItems.none }
    return EquipmentActionResult.Equipped(
        party = withMember(memberIndex, updatedMember).withInventoryItem(slot, updatedInventoryItem),
        memberNumber = memberNumber,
        inventorySlot = slot,
    )
}

/** Moves one equipped item from a member back into the first free inventory slot. */
fun PartyState.unequipToInventory(
    memberNumber: Int,
    kind: EquipmentKind,
): EquipmentActionResult {
    val memberIndex = memberNumber - 1
    val member =
        members.getOrNull(memberIndex)
            ?: return EquipmentActionResult.InvalidMember(this, memberNumber)
    val equipped = member.equipment.item(kind)
    if (equipped == DslDefaultItems.none) {
        return EquipmentActionResult.NothingEquipped(this, memberNumber, kind)
    }

    val slot =
        firstFreeInventorySlot()
            ?: return EquipmentActionResult.InventoryFull(this)
    val updated =
        withMember(memberIndex, member.withEquipmentItem(kind, DslDefaultItems.none))
            .withInventoryItem(slot, equipped)
    return EquipmentActionResult.Unequipped(updated, memberNumber, slot)
}

/** Applies a high-level equipment command to this party. */
fun PartyState.applyEquipmentCommand(
    command: EquipmentCommand,
    memberNumber: Int,
    inventorySlot: Int? = null,
    itemRecords: List<ItemRecordModel> = emptyList(),
): EquipmentActionResult =
    when (command) {
        EquipmentCommand.ReadyWeapon -> equipFromInventory(memberNumber, inventorySlot ?: 0, EquipmentKind.Weapon, itemRecords)
        EquipmentCommand.ReadyArmor -> equipFromInventory(memberNumber, inventorySlot ?: 0, EquipmentKind.Armor, itemRecords)
        EquipmentCommand.RemoveWeapon -> unequipToInventory(memberNumber, EquipmentKind.Weapon)
        EquipmentCommand.RemoveArmor -> unequipToInventory(memberNumber, EquipmentKind.Armor)
    }

/** Returns true when town-leave flow should prompt for a readyable inventory item. */
fun PartyState.needsTownLeaveReadyPrompt(
    command: EquipmentCommand,
    itemRecords: List<ItemRecordModel> = emptyList(),
): Boolean =
    when (command) {
        EquipmentCommand.ReadyWeapon ->
            hasReadyableInventoryEquipment(EquipmentKind.Weapon, itemRecords)
        EquipmentCommand.ReadyArmor ->
            hasReadyableInventoryEquipment(EquipmentKind.Armor, itemRecords)
        EquipmentCommand.RemoveWeapon,
        EquipmentCommand.RemoveArmor,
        -> false
    }

/** Consumes one torch if available. */
fun PartyState.consumeTorch(): TorchActionResult =
    if (resources.torches <= 0) {
        TorchActionResult.NoTorches(this)
    } else {
        TorchActionResult.Consumed(copy(resources = resources.copy(torches = resources.torches - 1)))
    }

/** Applies torch/max-depth rules for moving one level deeper in a dungeon. */
fun PartyState.tryDungeonDescent(
    currentDepth: Int,
    maxDepth: Int,
): DungeonDescentResult {
    require(currentDepth >= 0) { "current dungeon depth must be non-negative" }
    require(maxDepth >= 0) { "max dungeon depth must be non-negative" }
    if (resources.torches <= 0) return DungeonDescentResult.NoTorches(this)
    if (currentDepth >= maxDepth) return DungeonDescentResult.AtMaxDepth(this)
    return when (val result = consumeTorch()) {
        is TorchActionResult.Consumed -> DungeonDescentResult.Descended(result.party)
        is TorchActionResult.NoTorches -> DungeonDescentResult.NoTorches(result.party)
    }
}

/** Returns the item currently stored in inventory [slot]. */
fun PartyState.inventoryItem(slot: Int): ItemId? = inventory.firstOrNull { it.slot == slot }?.item

/** Returns terminal/menu choices for all non-empty inventory slots. */
fun PartyState.inventoryItemChoices(itemRecords: List<ItemRecordModel> = emptyList()): List<InventoryItemChoice> {
    val records = itemRecords.associateBy { it.id }
    return (1..InventorySaveSlotMax).mapNotNull { slot ->
        inventoryItem(slot)?.let { item ->
            val record = records[item]
            InventoryItemChoice(
                key = 'A' + slot - 1,
                slot = slot,
                item = item,
                label = record?.displayName ?: item.slug,
                kind = record?.kind ?: ItemKind.Gear,
            )
        }
    }
}

/** Returns the first empty persisted inventory slot, or `null` when full. */
fun PartyState.firstFreeInventorySlot(): Int? = (1..InventorySaveSlotMax).firstOrNull { inventoryItem(it) == null }

/** Returns this party with [slot] set to [item]. */
fun PartyState.withInventoryItem(
    slot: Int,
    item: ItemId?,
): PartyState {
    require(slot in 0..InventorySaveSlotMax) { "inventory slot $slot outside 0..$InventorySaveSlotMax" }
    val slots = inventory.associateBy { it.slot }.toMutableMap()
    slots[slot] = InventorySlotState(slot, item)
    return copy(inventory = slots.values.sortedBy { it.slot })
}

/** Computes resource capacity after carried item bonuses. */
fun PartyState.resourceCapacity(
    itemRecords: List<ItemRecordModel>,
    resource: Resource,
    baseCapacity: Int,
): Int {
    val byId = itemRecords.associateBy { it.id }
    val bonus =
        inventory
            .asSequence()
            .filter { it.slot in 1..InventorySaveSlotMax }
            .sumOf { slot ->
                val item = slot.item ?: return@sumOf 0
                byId[item]?.resourceCapacityBonus?.get(resource) ?: 0
            }
    return baseCapacity + bonus
}

/** Clamps resources that have authored capacity limits. */
fun PartyState.clampResourcesToCapacity(
    itemRecords: List<ItemRecordModel>,
    realmContent: RealmContentModel,
): PartyState {
    val foodBase = realmContent.baseResourceCapacity[Resource.Food] ?: return this
    val cap = resourceCapacity(itemRecords, Resource.Food, foodBase)
    return if (resources.food <= cap) this else copy(resources = resources.copy(food = cap))
}

private fun PartyState.hasReadyableInventoryEquipment(
    kind: EquipmentKind,
    itemRecords: List<ItemRecordModel>,
): Boolean {
    val candidateClasses =
        members
            .asSequence()
            .filter { member -> !member.dead && member.equipment.item(kind) == DslDefaultItems.none }
            .map { it.pcClass }
            .toSet()
    if (candidateClasses.isEmpty()) return false

    val records = itemRecords.associateBy { it.id }
    return inventory.any { slot ->
        slot.slot in 1..InventorySaveSlotMax &&
            slot.item?.let { item ->
                val record = records[item]
                record?.matches(kind) == true && candidateClasses.any(record::canEquip)
            } == true
    }
}

/** Computes carried camp-gear image/protection for camp rendering and damage. */
fun PartyState.campGearEffect(
    itemRecords: List<ItemRecordModel>,
    fallbackImage: ImageId,
): CampGearEffect {
    val byId = itemRecords.associateBy { it.id }
    val carriedRecords =
        inventory
            .asSequence()
            .filter { it.slot in 1..InventorySaveSlotMax }
            .mapNotNull { slot -> slot.item?.let(byId::get) }
            .toList()
    val protections = carriedRecords.flatMapTo(mutableSetOf()) { it.campProtection }
    val image = carriedRecords.firstNotNullOfOrNull { it.campImage } ?: fallbackImage
    return CampGearEffect(image = image, protectedBands = protections)
}

/** Returns this party with non-negative gold set to [gold]. */
fun PartyState.withGold(gold: Int): PartyState = copy(resources = resources.copy(gold = gold.coerceAtLeast(0)))

/** Counts inventory items that belong to [pool]. */
fun PartyState.countInventoryItems(pool: ItemPoolId): Int {
    val pooledItems = pool.items.toSet()
    return inventory.count { it.slot in 1..InventorySaveSlotMax && it.item in pooledItems }
}

/** Consumes up to [quantity] items belonging to [pool] from inventory. */
fun PartyState.consumeInventoryItems(
    pool: ItemPoolId,
    quantity: Int,
): PartyState {
    val pooledItems = pool.items.toSet()
    val consumedSlots =
        inventory
            .asSequence()
            .filter { it.slot in 1..InventorySaveSlotMax && it.item in pooledItems }
            .take(quantity.coerceAtLeast(0))
            .map { it.slot }
            .toSet()
    return copy(
        inventory = inventory.map { slot -> slot.copy(item = slot.item.takeUnless { slot.slot in consumedSlots }) },
    )
}

/** Returns this party with [milestone] achieved. */
fun PartyState.withMilestone(milestone: GameMilestoneId): PartyState =
    if (milestone in milestones) this else copy(milestones = (milestones + milestone).sortedBy { it.slug })

/** Returns this party without [milestone]. */
fun PartyState.withoutMilestone(milestone: GameMilestoneId): PartyState =
    if (milestone !in milestones) this else copy(milestones = milestones.filterNot { it == milestone })

/** Sets one party-scoped flag to a native value. */
fun PartyState.withFlagState(
    flag: String,
    native: String,
): PartyState =
    copy(
        flags =
            (flags.filterNot { it.flag.slug == flag } + runtimeFlagState(flag, native))
                .sortedWith(compareBy({ it.flag.slug }, { it.native })),
    )

/** Returns true when this party has [state]. */
fun PartyState.hasFlagState(state: FlagState): Boolean = flags.any { it.flag.slug == state.flag.slug && it.native == state.native }

/** Appends non-blank journal lines to this party. */
fun PartyState.withJournalLines(lines: List<String>): PartyState =
    copy(journal = journal + lines.filter { it.isNotBlank() }.map(JournalEntryState::Line))

private fun PartyState.withMember(
    index: Int,
    member: PartyMemberState,
): PartyState = copy(members = members.mapIndexed { i, existing -> if (i == index) member else existing })

private fun ItemRecordModel.matches(kind: EquipmentKind): Boolean =
    when (kind) {
        EquipmentKind.Weapon -> this.kind == ItemKind.Weapon
        EquipmentKind.Armor -> this.kind == ItemKind.Armor
    }

private fun ItemRecordModel.canEquip(pcClass: PcClass): Boolean = equippableBy.isEmpty() || pcClass in equippableBy

private fun EquipmentState.item(kind: EquipmentKind): ItemId =
    when (kind) {
        EquipmentKind.Weapon -> weapon
        EquipmentKind.Armor -> armor
    }

private fun PartyMemberState.withEquipmentItem(
    kind: EquipmentKind,
    item: ItemId,
): PartyMemberState =
    copy(
        equipment =
            when (kind) {
                EquipmentKind.Weapon -> equipment.copy(weapon = item)
                EquipmentKind.Armor -> equipment.copy(armor = item)
            },
    )

/** Prompt metadata derived from one [EquipmentCommand]. */
data class EquipmentPromptModel(
    val command: EquipmentCommand,
    val kind: EquipmentKind,
    val memberFilter: MemberChoiceFilter,
    val inventoryFilter: InventorySlotChoiceFilter?,
)

/** Current prompt or completion state for [EquipmentPromptSession]. */
sealed interface EquipmentPromptStep {
    data class ChooseInventorySlot(
        val prompt: TextBlock,
        val filter: InventorySlotChoiceFilter,
    ) : EquipmentPromptStep

    data class ChooseMember(
        val prompt: TextBlock,
        val filter: MemberChoiceFilter,
    ) : EquipmentPromptStep

    data class Finished(
        val result: EquipmentActionResult,
    ) : EquipmentPromptStep
}

/** Reusable state machine for choosing equipment slot/member and applying the command. */
data class EquipmentPromptSession(
    val command: EquipmentCommand,
    val party: PartyState,
    val step: EquipmentPromptStep,
    val itemRecords: List<ItemRecordModel> = emptyList(),
    val inventorySlot: Int? = null,
    val prompts: EquipmentPromptsModel = EquipmentPromptsModel(),
) {
    fun apply(input: EquipmentPromptInput): EquipmentPromptSession =
        when (val current = step) {
            is EquipmentPromptStep.ChooseInventorySlot -> {
                val slot =
                    (input as? EquipmentPromptInput.InventorySlot)
                        ?: error("equipment session is choosing an inventory slot")
                copy(
                    step =
                        EquipmentPromptStep.ChooseMember(
                            prompts.who,
                            command.prompt().memberFilter,
                        ),
                    inventorySlot = slot.slot,
                )
            }
            is EquipmentPromptStep.ChooseMember -> {
                val member =
                    (input as? EquipmentPromptInput.Member)
                        ?: error("equipment session is choosing a member")
                val result = party.applyEquipmentCommand(command, member.memberNumber, inventorySlot, itemRecords)
                copy(party = result.party, step = EquipmentPromptStep.Finished(result))
            }
            is EquipmentPromptStep.Finished -> error("equipment session is already finished: $current")
        }

    companion object {
        /** Starts an equipment prompt from a command and party. */
        fun start(
            command: EquipmentCommand,
            party: PartyState,
            itemRecords: List<ItemRecordModel> = emptyList(),
            prompts: EquipmentPromptsModel = EquipmentPromptsModel(),
        ): EquipmentPromptSession {
            val prompt = command.prompt()
            val step =
                prompt.inventoryFilter?.let {
                    EquipmentPromptStep.ChooseInventorySlot(prompts.inventory, it)
                } ?: EquipmentPromptStep.ChooseMember(prompts.who, prompt.memberFilter)
            return EquipmentPromptSession(command, party, step, itemRecords, prompts = prompts)
        }

        /** Starts an equipment prompt with the inventory slot already selected. */
        fun startWithInventorySlot(
            command: EquipmentCommand,
            party: PartyState,
            slot: Int,
            itemRecords: List<ItemRecordModel> = emptyList(),
            prompts: EquipmentPromptsModel = EquipmentPromptsModel(),
        ): EquipmentPromptSession {
            val prompt = command.prompt()
            require(prompt.inventoryFilter != null) { "$command does not choose inventory items" }
            return EquipmentPromptSession(
                command = command,
                party = party,
                step = EquipmentPromptStep.ChooseMember(prompts.who, prompt.memberFilter),
                itemRecords = itemRecords,
                inventorySlot = slot,
                prompts = prompts,
            )
        }
    }
}

/** Returns prompt filters and equipment kind for this command. */
fun EquipmentCommand.prompt(): EquipmentPromptModel =
    when (this) {
        EquipmentCommand.ReadyWeapon ->
            EquipmentPromptModel(
                command = this,
                kind = EquipmentKind.Weapon,
                memberFilter = MemberChoiceFilter.AliveOnly,
                inventoryFilter = InventorySlotChoiceFilter.NonEmpty,
            )
        EquipmentCommand.ReadyArmor ->
            EquipmentPromptModel(
                command = this,
                kind = EquipmentKind.Armor,
                memberFilter = MemberChoiceFilter.AliveOnly,
                inventoryFilter = InventorySlotChoiceFilter.NonEmpty,
            )
        EquipmentCommand.RemoveWeapon ->
            EquipmentPromptModel(
                command = this,
                kind = EquipmentKind.Weapon,
                memberFilter = MemberChoiceFilter.Any,
                inventoryFilter = null,
            )
        EquipmentCommand.RemoveArmor ->
            EquipmentPromptModel(
                command = this,
                kind = EquipmentKind.Armor,
                memberFilter = MemberChoiceFilter.Any,
                inventoryFilter = null,
            )
    }

/** Returns the town-leave prompt text for ready commands. */
fun EquipmentCommand.townLeavePrompt(prompts: EquipmentPromptsModel = EquipmentPromptsModel()): TextBlock =
    when (this) {
        EquipmentCommand.ReadyWeapon -> prompts.readyWeapons
        EquipmentCommand.ReadyArmor -> prompts.readyArmors
        EquipmentCommand.RemoveWeapon,
        EquipmentCommand.RemoveArmor,
        -> error("$this is not a town-leave ready command")
    }
