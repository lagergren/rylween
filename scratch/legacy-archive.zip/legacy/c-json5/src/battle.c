#include "ryl.h"
#include "res.h"
#include "battle.h"
#include "driv.h"
#include "inventory.h"
#include "party.h"
#include "primitives.h"
#include "replay_knobs.h"
#include "script.h"
#include "subs.h"
#include "towne.h"

static void exp_check(void);

/*
** Never find and never fool
** The first one drinks the poison pool
** The third one reads the ancient tome
** The last one breaks the double dome
*/

void encounter(int32_t foe, int32_t mandatory) {
    assert(foe >= 1);
    assert(party_current_slot() >= 1 && party_current_slot() <= party_count());
    /* Per-encounter combatant cap comes from
       data/world.json5 combat.encounter_foe_count_max — read once
       up front so mh[] / deadc[] can size to the actual cap rather
       than carry the historical static 15. */
    const int32_t foe_max = res_combat_int("encounter_foe_count_max");
    assert(foe_max >= 1);
    char fn[80], str[80], c, d;
    int32_t n1 = 0, n2 = 0; /* Min & Max nr */
    int32_t h1 = 0, h2 = 0; /* Min & Max hp */
    int32_t sp;             /* Fire frost hold */
    int32_t im;             /* Immune to magic? */
    int32_t ws = 0;         /* WS */
    int32_t x, loot_id, who, dp, g, noc, mhtemp;
    int32_t mh[foe_max], deadc[foe_max];
    int32_t oc;
    uint8_t defend = 0;

    int32_t antimagic = 0, confused = 0, held = 0, playerheld = 0, playerconfused = 0;

    clw();
    tx0(res_text("battle.encounter.banner"));
    clr_map_window();
    blitgfx(encounterpic + ryl_random(0, res_combat_int("encounter_pic_count") - 1));
    ryl_delay(400);
    sp = 0;
    im = 0;
    {
        const ryl_monster *m = res_monster(foe);
        if (m) {
            strncpy(fn, m->name, sizeof fn - 1);
            fn[sizeof fn - 1] = 0;
            n1 = m->n1;
            n2 = m->n2;
            h1 = m->h1;
            h2 = m->h2;
            ws = m->ws;
            sp = m->sp;
            im = m->im;
        }
        if (m && m->n2_lv_div > 0) {
            n2 = m->n2 + pa_first_level() / m->n2_lv_div;
        }
    }

    noc = ryl_random(1, n2);
    if (noc < n1) {
        noc = n1;
    }
    /* Replay-mode override (rk_force_encounter_noc): pin the foe
       count after the natural roll above so the post-encounter RNG
       state matches the unforced path. */
    noc = rk_force_encounter_noc(noc);
    int32_t party_avg = pa_level_avg();
    res_binding hp_bindings[] = {
        {"h1_base", h1},
        {"h2_base", h2},
        {"party_avg", party_avg},
        {"first_level", pa_first_level()},
    };
    size_t hp_n = sizeof hp_bindings / sizeof hp_bindings[0];
    h1 = res_formula_int_n("encounter_h1_scaled", hp_bindings, hp_n);
    h2 = res_formula_int_n("encounter_h2_scaled", hp_bindings, hp_n);
    if (h1 > h2) {
        h1 = h2;
    }

    if (noc > foe_max) {
        noc = foe_max;
    }
    assert(noc >= 1 && noc <= foe_max);
    assert(h1 <= h2);

    ws += pa_first_level();

    for_each_monster(i, noc) {
        mhtemp = ryl_random(1, h2);
        if (mhtemp < h1) {
            mhtemp = h1;
        }
        mh[i] = mhtemp;
        deadc[i] = 0;
    }

    snprintf(str, sizeof str, "%d %s", noc, fn);
    if (noc > 1) {
        str_append(str, sizeof str, "s");
    }
    while (1) {
        clw();
        tx0(res_text("battle.encounter.you_face"));
        tx("%s\r\n\r\n", str);
        tx0(res_text("battle.prompt.fight"));
        tx0(res_text("battle.prompt.run"));

        c = key();
        c = toupper(c);
        if (c == 'F' || c == 'R') {
            break;
        }
    }
    if (c == 'R') {
        if (!mandatory) {
            if (ryl_chance(res_combat_int("flee_chance"))) {
                clw();
                tx0(res_text("battle.run.coward"));
                ryl_delay(800);
                clw();
                clr_map_window();
                return;
            } else {
                clw();
                tx0(res_text("battle.run.fail_away"));
                ryl_delay(800);
                clw();
            }
        } else {
            clw();
            tx0(res_text("battle.run.desperate_fail"));
            ryl_delay(800);
            clw();
        }
    }

    clw();
    tx0(res_text("battle.prompt.blood_flow"));
    ryl_delay(1000);

    g = 0;
    while (1) {
        clw();
        if (pa_is_alive(g) && !playerheld) {
        combat:
            tx("%s\r\n", pm_name(pm_cur(g)));
            tx0(res_text("battle.prompt.what_now"));
            tx0(res_text("battle.prompt.attack"));
            tx0(res_text("battle.prompt.defend"));
            tx0(res_text("battle.prompt.use_item"));
            tx0(res_text("battle.prompt.battle_cry"));
            if (pm_is_mage(pm_cur(g))) {
                tx0(res_text("battle.prompt.cast_spell"));
            }
            /* Per-turn action-menu input loop. The accept set comes
               from data/world.json5 combat_keys[] — adding a new menu
               key is a data edit + a wired action body in the if-
               cascade below. Keypress acceptance is cond-blind so the
               legacy non-mage 'C' fall-through survives: the input
               loop exits on any data-listed key, and the action body
               (e.g. the c == 'C' arm at the cast-spell branch) gates
               itself on the corresponding predicate. The body
               cascade itself stays in C — a function-pointer table
               would need to ferry every battle-loop local (g, defend,
               ws, mh[], deadc[], ...) through a context struct. */
            const int n_keys = res_combat_keys_count();
            while (1) {
                c = key();
                c = toupper(c);
                int matched = 0;
                for (int ki = 0; ki < n_keys; ki++) {
                    char ekey;
                    if (res_combat_key_at(ki, &ekey, NULL, NULL) &&
                        c == ekey) {
                        matched = 1;
                        break;
                    }
                }
                if (matched) {
                    break;
                }
            }

            /****************************************************************************/
            if (c == 'U') {
                clw();
                tx0(res_text("battle.prompt.use_what"));
                inv_list();
                d = key();
                d = toupper(d);
                oc = 0;
                if (inv_letter_in_range(d)) {
                    oc = pa_inventory(inv_slot_from_letter(d));
                    if (!item_is_magic_item(oc)) {
                        clw();
                        tx0(res_text("battle.prompt.not_possible"));
                        ryl_delay(1000);
                        clw();
                        goto combat;
                    } else {
                        if (im) {
                            pa_set_inventory(inv_slot_from_letter(d), 0);
                            clw();
                            tx0(res_text("battle.item.magic_immune"));
                            ryl_delay(1000);
                            clw();
                        } else {
                            /* §23.B closed: every magic item has an
                               `effect:` DSL body in magic_items.json5;
                               the dispatcher routes every Use-Item
                               invocation through play_spell_body.
                               Inventory consume is body-owned
                               (pa_set_inventory engine_call) so
                               conditional consumers like
                               gem_of_resurrection can defer to their
                               success branch. */
                            const char *slug = NULL;
                            const void *effect =
                                res_magic_item_effect_node(oc, &slug);
                            if (!effect) {
                                char err[96];
                                snprintf(err, sizeof err,
                                         "magic_items: no effect body for id %d",
                                         (int)oc);
                                ryl_die(err);
                            }
                            char caster_buf[8];
                            snprintf(caster_buf, sizeof caster_buf, "%d", g);
                            char inv_slot_buf[8];
                            snprintf(inv_slot_buf, sizeof inv_slot_buf,
                                     "%d", inv_slot_from_letter(d));
                            ryl_bind binds[] = {
                                {"caster_idx", caster_buf},
                                {"monster_name", fn},
                                {"inv_slot", inv_slot_buf},
                                {0},
                            };
                            int ws_int = ws;
                            int action_retry = 0;
                            struct script_combat_ctx ctx = {
                                .noc = noc,
                                .mh = mh,
                                .deadc = deadc,
                                .fn = fn,
                                .confused = &confused,
                                .held = &held,
                                .antimagic = &antimagic,
                                .ws = &ws_int,
                                .action_retry = &action_retry,
                                .h2 = h2,
                            };
                            char id_buf[80];
                            snprintf(id_buf, sizeof id_buf,
                                     "magic_items.%s",
                                     slug ? slug : "(unknown)");
                            play_spell_body(id_buf, effect, binds, &ctx);
                            ws = (int32_t)ws_int;
                            if (action_retry) {
                                /* gem_of_resurrection's not-dead branch
                                   — re-prompt the player's action menu
                                   without consuming a turn (legacy
                                   `goto combat`). */
                                goto combat;
                            }
                        }
                    }
                }
            }
            /****************************************************************************/
            if (c == 'C' && pm_is_mage(pm_cur(g))) {
                pm_t caster = pm_cur(g);
                const ryl_spell *s;
                clw();
                for (int slot = 1; slot <= 6; slot++) {
                    s = res_spell("mage", slot);
                    if (!s) {
                        continue;
                    }
                    tx("%d. %-13s(%3d/%3d)\r\n", slot, s->name,
                       s->base_cost + pm_level(caster), pm_magic(caster));
                }
                tx0(res_text("battle.spell.abort"));
                while (1) {
                    d = key();
                    if (d >= '1' && d <= '7') {
                        break;
                    }
                }
                if (im) {
                    clw();
                    tx0(res_text("battle.spell.fizzle"));
                    ryl_delay(2000);
                }
                if (d == '7') {
                    clw();
                    goto combat;
                }
                if (im) {
                    s = NULL; /* swallow the key press, no effect */
                } else {
                    s = res_spell("mage", d - 48);
                }
                if (s) {
                    if (pm_magic(caster) < (s->base_cost + pm_level(caster))) {
                        clw();
                        tx0(res_text("battle.spell.not_enough_magic"));
                        ryl_delay(1000);
                    } else {
                        pm_add_magic(caster, -(s->base_cost + pm_level(caster)));
                        /* §22 Lane A: every mage spell carries a do:
                           body — res_spell_node always resolves. */
                        const void *spell_node = res_spell_node("mage", d - 48);
                        char caster_buf[8];
                        snprintf(caster_buf, sizeof caster_buf, "%d", g);
                        ryl_bind binds[] = {
                            {"caster_idx", caster_buf},
                            {"monster_name", fn},
                            {0},
                        };
                        int ws_int = ws;
                        struct script_combat_ctx ctx = {
                            .noc = noc,
                            .mh = mh,
                            .deadc = deadc,
                            .fn = fn,
                            .confused = &confused,
                            .held = &held,
                            .antimagic = &antimagic,
                            .ws = &ws_int,
                            .h2 = h2,
                        };
                        play_spell_body(s->id ? s->id : "mage.(unknown)",
                                        spell_node, binds, &ctx);
                        ws = (int32_t)ws_int;
                    }
                }
            }
            /****************************************************************************/
            if (c == 'B') {
                clw();
                tx0(res_text("battle.cry.hi_yaaaa"));
                ryl_delay(800);
                tx0(res_text("battle.cry.off_guard"));
                int32_t cry_pen = res_combat_int("battle_cry.ws_penalty");
                if (ws > cry_pen) {
                    ws -= cry_pen;
                }
                ryl_delay(1500);
            }
            /****************************************************************************/
            if (c == 'D') {
                pm_t pmg = pm_cur(g);
                if (pm_hit_points(pmg) + pm_level(pmg) > pm_health(pmg)) {
                    pm_set_hit_points(pmg, pm_health(pmg));
                } else {
                    pm_add_hit_points(pmg, pm_level(pmg));
                }
                clw();
                if (defend < res_combat_int("defend.rest_threshold")) {
                    tx0(res_text("battle.rest.gain_hits"));
                    ryl_delay(1000);
                } else {
                    tx0(res_text("battle.defend.stance"));
                    ryl_delay(1000);
                }
                defend++;
                int32_t cap = res_combat_int("defend_cap");
                if (cap > 0 && defend > cap) {
                    defend = (uint8_t)cap;
                }
                int32_t def_pen = res_combat_int("defend.ws_penalty");
                if (ws > def_pen) {
                    ws -= def_pen;
                }
            }
            /****************************************************************************/
            if (c == 'A') {
                while (1) {
                    clw();
                    tx_fmt("battle.prompt.who", NULL);
                    for_each_monster(i, noc) {
                        if (deadc[i]) {
                            strcpy(str, "Dead.");
                        } else {
                            strcpy(str, "Alive.");
                        }
                        tx("%c. %-7s (%3d hp)\r\n", 'A' + i, str, mh[i]);
                    }
                    d = key();
                    d = toupper(d);
                    if (d >= 'A' && d < 'A' + noc && !deadc[d - 'A']) {
                        break;
                    }
                }
                who = d - 'A';
                x = pm_weapon_skill(pm_cur(g));
                if (playerconfused) {
                    int32_t cdiv = res_combat_int("attack.confusion_div");
                    if (cdiv > 0) {
                        x /= cdiv;
                    }
                }
                if (ryl_chance(x + res_combat_int("attack.hit_bonus"))) {
                    /* HIT */
                    dp = obdamage(pm_weapon(pm_cur(g)));
                    dp += ryl_random(0, res_combat_int("attack.damage_spread_max"));
                    int32_t hpd = res_combat_int("hp_defense_div");
                    if (hpd > 0) {
                        dp += pm_hit_points(pm_cur(g)) / hpd;
                    }
                    clw();
                    char dp_buf[16];
                    snprintf(dp_buf, sizeof dp_buf, "%d", dp);
                    ryl_bind hit_binds[] = {
                        {"attacker", pm_name(pm_cur(g))},
                        {"dmg", dp_buf},
                        {0},
                    };
                    tx_fmt("battle.attack.hits_for", hit_binds);
                    tx_fmt("battle.attack.damage_pts", hit_binds);
                    ryl_delay(600);
                    mh[who] -= dp;
                    if (mh[who] <= 0) {
                        mh[who] = 0;
                        deadc[who] = 1;
                        tx0(res_text("battle.killed"));
                        ryl_delay(600);
                    }
                } else {
                    /* MISS */
                    clw();
                    ryl_bind miss_binds[] = {
                        {"attacker", pm_name(pm_cur(g))},
                        {0},
                    };
                    tx_fmt("battle.attack.misses", miss_binds);
                    ryl_delay(600);
                }
            }
            /* SLUTET */

            x = 0;
            for_each_monster(i, noc) {
                if (!deadc[i]) {
                    x = 1;
                }
            }
            if (!x) {
                /* WIN */
                /* 100-111, 36-46 */
                clr_map_window();
                blitgfx(wonbattlepic);
                clw();
                tx0(res_text("battle.victory.bested"));
                res_binding reward_bindings[] = {
                    {"noc", noc},
                    {"h2", h2},
                    {"weapon_skill", ws},
                    {"sp", sp},
                };
                size_t reward_n = sizeof reward_bindings / sizeof reward_bindings[0];
                int32_t exp_gain =
                    res_formula_int_n("reward_xp_per_survivor", reward_bindings, reward_n);
                int32_t gold_gain =
                    res_formula_int_n("reward_gold_party", reward_bindings, reward_n);
                char exp_buf[16], gold_buf[16];
                snprintf(exp_buf, sizeof exp_buf, "%d", exp_gain);
                snprintf(gold_buf, sizeof gold_buf, "%d", gold_gain);
                ryl_bind reward_binds[] = {
                    {"experience", exp_buf},
                    {"gold", gold_buf},
                    {0},
                };
                tx0(res_text("battle.victory.each_survivor"));
                tx_fmt("battle.victory.exp_pts", reward_binds);
                tx_fmt("battle.victory.and_gold", reward_binds);
                ryl_delay(1000);
                pa_add_kills((uint32_t)noc);
                x = inv_find_empty();
                loot_id = 0;
                if (x) {
                    if (ryl_chance(res_combat_int("drop_tables.default.drop_chance"))) {
                        if (ryl_chance(res_combat_int("drop_tables.default.treasure_chance"))) {
                            loot_id = ryl_random(res_combat_int("drop_tables.default.treasure_lo"),
                                                 res_combat_int("drop_tables.default.treasure_hi"));
                        } else {
                            loot_id = ryl_random(res_combat_int("drop_tables.default.magic_lo"),
                                                 res_combat_int("drop_tables.default.magic_hi"));
                        }
                        clw();
                        ryl_bind loot_binds[] = {
                            {"object_name", object(loot_id)},
                            {0},
                        };
                        tx0(res_text("battle.victory.you_find_a"));
                        tx_fmt("battle.victory.found_obj", loot_binds);
                        ryl_delay(1500);
                        pa_set_inventory(x, loot_id);
                    }
                }
                party_add_gold(gold_gain);
                for_each_party_member(i) {
                    pm_t pm = pm_cur(i);
                    if (!pm_dead(pm)) {
                        pm_add_experience(pm, (uint32_t)exp_gain);
                    }
                }
                exp_check();
                clr_map_window();
                clw();
                return;
            }
        }
        g++;
        /****************************************************************************/
        if (g == res_party_member_max()) {
            playerheld = 0;
            playerconfused = 0;
            /* MONSTERS GET NASTY */
            g = 0;
            for_each_monster(m, noc) {
                if (pa_alive_count() == 0) {
                    lose_game();
                }
                if (!deadc[m] && !held) {
                    if (!antimagic && sp &&
                        ryl_chance(15 + sp / 2)) /* MOSTERS PRACTICE NASTY MAGIC */
                    {
                        /* §23.A: monster nasty-magic dispatcher.
                           clw + "<monster> casts" stay in C (shared
                           prefix across all spells); the spell-pick
                           random(0, n-1) and the body run via the
                           script DSL. n comes from data so an author
                           can grow the spell list without touching
                           battle.c. RNG order matches the legacy
                           switch — pick draw fires AFTER the casts
                           line and BEFORE the body's first emit. */
                        clw();
                        ryl_bind cast_binds[] = {
                            {"monster_name", fn},
                            {0},
                        };
                        tx_fmt("battle.monster.casts", cast_binds);
                        int spell_count = res_monster_spell_count();
                        if (spell_count > 0) {
                            int pick = ryl_random(0, spell_count - 1);
                            const void *spell_body =
                                res_monster_spell_node(pick);
                            if (spell_body) {
                                char caster_buf[8];
                                snprintf(caster_buf, sizeof caster_buf,
                                         "%d", m);
                                ryl_bind binds[] = {
                                    {"caster_idx", caster_buf},
                                    {"monster_name", fn},
                                    {0},
                                };
                                int ws_int = ws;
                                struct script_combat_ctx ctx = {
                                    .noc = noc,
                                    .mh = mh,
                                    .deadc = deadc,
                                    .fn = fn,
                                    .confused = &confused,
                                    .held = &held,
                                    .antimagic = &antimagic,
                                    .ws = &ws_int,
                                    .player_held = &playerheld,
                                    .player_confused = &playerconfused,
                                    .h2 = h2,
                                };
                                char id_buf[64];
                                snprintf(id_buf, sizeof id_buf,
                                         "monster_spells.spells[%d]",
                                         pick);
                                play_spell_body(id_buf, spell_body, binds,
                                                &ctx);
                                ws = (int32_t)ws_int;
                            }
                        }
                    } else {
                        /* §23.A follow-up: monster-melee fallback arm
                           lifted to monster_spells.melee.do. C side
                           sets up the same combat ctx as the cast
                           branch above and binds attacker_idx + the
                           monster_name carrier; everything else
                           (target pick, hit roll, damage formula,
                           death narration) lives in the script body. */
                        const void *melee_body = res_monster_melee_node();
                        if (melee_body) {
                            char attacker_buf[8];
                            snprintf(attacker_buf, sizeof attacker_buf,
                                     "%d", m);
                            ryl_bind melee_binds[] = {
                                {"attacker_idx", attacker_buf},
                                {"monster_name", fn},
                                {0},
                            };
                            int ws_int = ws;
                            struct script_combat_ctx ctx = {
                                .noc = noc,
                                .mh = mh,
                                .deadc = deadc,
                                .fn = fn,
                                .confused = &confused,
                                .held = &held,
                                .antimagic = &antimagic,
                                .ws = &ws_int,
                                .player_held = &playerheld,
                                .player_confused = &playerconfused,
                                .h2 = h2,
                            };
                            play_spell_body("monster_spells.melee",
                                            melee_body, melee_binds,
                                            &ctx);
                            ws = (int32_t)ws_int;
                        }
                    }
                }
            }
            antimagic = 0;
            if (confused) {
                confused = 0;
                ws *= 2;
            }
            held = 0;
            clw();
            if (playerheld) {
                tx0(res_text("battle.party.held"));
                ryl_delay(1000);
            } else {
                if (pa_alive_count() == 0) {
                    lose_game();
                }
                status_line();
                tx0(res_text("battle.encounter.still_face"));
                x = 0;
                for_each_monster(i, noc) {
                    if (!deadc[i]) {
                        x++;
                    }
                }
                snprintf(str, sizeof str, "%d %s", x, fn);
                if (x > 1) {
                    str_append(str, sizeof str, "s");
                }
                tx("%s\r\n\r\n", str);
                tx0(res_text("battle.prompt.fight"));
                tx0(res_text("battle.prompt.run"));
                while (1) {
                    c = key();
                    c = toupper(c);
                    if (c == 'F') {
                        break;
                    }
                    if (c == 'R') {
                        if (ryl_chance(res_combat_int("run.desperate_chance")) || mandatory) {
                            clw();
                            tx0(res_text("battle.run.fail_away"));
                            ryl_delay(1000);
                            break;
                        } else {
                            clw();
                            tx0(res_text("battle.run.escaped"));
                            clr_map_window();
                            return;
                        }
                    }
                }
            }
        }
    }
    clr_map_window();
    clw();
}
/****************************************************************************/

void exp_check(void) {
    /* Per-member level-deltas. VLA sized off res_party_member_max so
       experimental N != 4 parties don't outrun the buffer; +1 keeps
       the slot indexing 0..N-1 safe even when the cap is 0. */
    const int pm_max = res_party_member_max();
    int32_t add[pm_max + 1];
    memset(add, 0, sizeof add);

    /* Hard ceiling on levels — matches the highest authored
       xp_thresholds entry. Lifted to balance.level_up.max_level so
       a longer thresholds table only needs the data edit. */
    const int32_t max_level = res_int_path("balance.level_up.max_level");

    for_each_party_member(i) {
        pm_t pm = pm_cur(i);
        int32_t l = pm_level(pm);
        uint32_t e = pm_experience(pm);
        for (int n = l + 1; n <= max_level; n++) {
            int32_t need = res_xp_threshold(n);
            if (need <= 0 || e < (uint32_t)need) {
                break;
            }
            add[i]++;
        }
    }

    /* §24bis phase 3: pm_class_sym already returns the lowercase
       enum key ("fighter" / "thief" / ...) — the same string the
       classes.<cls> shard keys carry. Missing-class members surface
       "" and res_class_levelup returns 0 (no-op). */
    for_each_party_member(i) {
        if (add[i]) {
            pm_t pm = pm_cur(i);
            clw();
            char gain_buf[16];
            snprintf(gain_buf, sizeof gain_buf, "%d", add[i]);
            ryl_bind gain_binds[] = {
                {"name", pm_name(pm)},
                {"levels", gain_buf},
                {0},
            };
            tx_fmt("battle.expgain.gains", gain_binds);
            tx0(res_text("battle.expgain.exp_levels"));
            ryl_delay(600);
            pm_add_level(pm, add[i]);
            const char *cls = pm_class_sym(pm);
            pm_add_weapon_skill(pm, res_class_levelup(cls, "weapon_skill"));
            pm_add_health(pm, res_class_levelup(cls, "health"));
            pm_add_wisdom(pm, res_class_levelup(cls, "wisdom"));
            pm_add_charisma(pm, res_class_levelup(cls, "charisma"));
            res_binding hp_binds[] = {
                {"health", pm_health(pm)},
            };
            size_t hp_n = sizeof hp_binds / sizeof hp_binds[0];
            pm_hit_points_floor(pm,
                                res_formula_int_n("level_up_hp_floor",
                                                  hp_binds, hp_n));
        }
    }
}
